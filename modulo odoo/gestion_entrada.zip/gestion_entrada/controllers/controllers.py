# -*- coding: utf-8 -*-
# from odoo import http


# class GestionEntrada(http.Controller):
#     @http.route('/gestion_entrada/gestion_entrada', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/gestion_entrada/gestion_entrada/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('gestion_entrada.listing', {
#             'root': '/gestion_entrada/gestion_entrada',
#             'objects': http.request.env['gestion_entrada.gestion_entrada'].search([]),
#         })

#     @http.route('/gestion_entrada/gestion_entrada/objects/<model("gestion_entrada.gestion_entrada"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('gestion_entrada.object', {
#             'object': obj
#         })

