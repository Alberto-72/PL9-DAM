#-*- coding: utf-8 -*-

from odoo import models, fields, api
import re

class gestion_entrada(models.Model):
    _name = 'gestion_entrada.gestion_entrada'
    _description = 'gestion_entrada.gestion_entrada'

    name = fields.Char()
    description = fields.Text()

class User(models.AbstractModel):
    _name = "gestion_entrada.user"
    _description = "Datos usuario base"

    uid = fields.Char(string="UID NFC")
    name = fields.Char(string="Nombre", required=True)
    surname = fields.Char(string="Apellidos", required=True)
    birth_date = fields.Date(string="Fecha de nacimiento", required=True)
    email = fields.Char(string="email", required=True)

    @api.constrains('email')
    def _check_email_format(self):
        for record in self:
            if record.email and not re.match(r'^[a-z0-9]+@[a-z0-9]+\.[a-z0-9]{2,4}$', record.email):
                raise ValueError("El formato del email no es correcto")

class Alumno(models.Model):
    _name = "gestion_entrada.alumno"
    _description = "Datos alumno"
    _inherit = "gestion_entrada.user"
    
    school_year = fields.Selection(
        [
            ('1ESO', '1º Educación Secundaria Obligatoria'),
            ('2ESO', '2º Educación Secundaria Obligatoria'),
            ('3ESO', '3º Educación Secundaria Obligatoria'),
            ('3ESODIV', '3º ESO - Diversificación'),
            ('4ESO', '4º Educación Secundaria Obligatoria'),
            ('4ESODIV', '4º ESO - Diversificación'),
            ('1BACH_CIEN', '1º Bachillerato Ciencias y Tecnología'),
            ('2BACH_CIEN', '2º Bachillerato Ciencias y Tecnología'),
            ('1BACH_HCS', '1º Bachillerato Humanidades y C. Sociales'),
            ('2BACH_HCS', '2º Bachillerato Humanidades y C. Sociales'),
            ('1CFGB_AGR', '1º CFGB Aprovechamientos Forestales'),
            ('2CFGB_AGR', '2º CFGB Agrojardinería y Comp. Florales'),
            ('1CFGM_SMR', '1º CFGM Sistemas Microinformáticos y Redes'),
            ('2CFGM_SMR', '2º CFGM Sistemas Microinformáticos y Redes'),
            ('1CFGM_ACMN', '1º CFGM Aprovechamiento y Cons. Medio Natural'),
            ('2CFGM_ACMN', '2º CFGM Aprovechamiento y Cons. Medio Natural'),
            ('1DAM', '1º CFGS Desarrollo de Aplicaciones Multiplataforma'),
            ('2DAM', '2º CFGS Desarrollo de Aplicaciones Multiplataforma'),
            ('1CFGS_GFMN', '1º CFGS Gestión Forestal y del Medio Natural'),
            ('2CFGS_GFMN', '2º CFGS Gestión Forestal y del Medio Natural'),
        ],
        string="Curso escolar",
        required=True
    )

    can_bus = fields.Boolean(string="Transporte")
    photo = fields.Image(string="Foto del alumno", max_width=1024, max_height=1024)

class Profesor(models.Model):
    _name = "gestion_entrada.profesor"
    _description = "Datos profesor"
    _inherit = "gestion_entrada.user"

    username = fields.Char(string="Username", required=True)
    user_pass = fields.Char(string="Password", required=True)
    is_management = fields.Boolean(string="Es de la directiva", required=True)
    photo = fields.Image(string="Foto del profesor", max_width=1024, max_height=1024)

class Registro(models.Model):
    _name = "gestion_entrada.registro"
    _description = "Registros entradas"

    uid = fields.Char(string="UID NFC", required=True)
    dateTime = fields.Datetime(string="fecha y hora")
    usr_type = fields.Selection(
        [
            ("profesor", "Profesor"),
            ("alumno", "Alumno"),
        ], 
        required=True
    )

    reg_type = fields.Selection(
        [   #Salidas
            ("salida_anticipada", "Salida Anticipada"), # Salida antes de las 14:00 y no es bus y no es recreo
            ("salida_recreo", "Salida Recreo"), # Salida entre las 10:45 y 11:15
            ("salida_bus", "Salida Bus"), # Salida entre 13:50 y 14:00
            ("salida_anticipada_autorizada","Salida Anticipada Autorizada"), # Antes de las 14:00 y no es bus y es mayor de edad
            ("salida_regular", "Salida Regular"), # 14:00
            ("salida_prof", "Salida Profesor"), # Salida de cualquier profesor del centro
            #Entradas
            ("entrada_puntual", "Entrada Puntual"), # Entrada antes de las 8:05
            ("entrada_recreo", "Entrada Recreo"), # Entrada entre las 10:45 y 11:15
            ("entrada_tardia", "Entrada tardia"), # Entrada posterior a las 8:05 y no es recreo
            ("entrada_prof", "Entrada Profesor"), # Cualquier entrada de un profesor al centro
            #Incidencias
            ("error", "Incidencia"), # Cualquier error de lectura / no existencia del NFC
            ("no_autorizado", "No Autorizado (Salida o Entrada)"), # Errores de salida de menores que no son autorizados
        ],
        string="Tipo de registro",
        required=True
    )
    
    alumno_id = fields.Many2one('gestion_entrada.alumno', string="Alumno")
    profesor_id = fields.Many2one('gestion_entrada.profesor', string="Profesor")
    
    alumno_name = fields.Char(related='alumno_id.name', string="Nombre Alumno")
    alumno_surname = fields.Char(related='alumno_id.surname', string="Apellidos Alumno")
    alumno_curso = fields.Selection(related='alumno_id.school_year', string="Curso Alumno")
    
    profesor_name = fields.Char(related='profesor_id.name', string="Nombre Profesor")
    profesor_surname = fields.Char(related='profesor_id.surname', string="Apellidos Profesor")