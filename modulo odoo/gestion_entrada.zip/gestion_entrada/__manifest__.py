# -*- coding: utf-8 -*-
{
    'name': "gestion_entrada",

    'summary': "Modulo de control de entrada de alumnos y progesores al centro",

    'description': """
Modulo de control de entrada de alumnos y progesores al centro
    """,

    'author': "Alberto",
    'website': "https://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'installable': True,
    'application': True,
    'category': 'Productivity',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base'],

    # always loaded
    'data': [
        'security/groups.xml',
        'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}

